# Retrieval Platform Bounded Context
